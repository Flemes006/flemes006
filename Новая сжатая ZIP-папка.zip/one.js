element.onlick = function goTop {
    document.body.scrollTop = 0; }